<?php
App::uses('AppModel', 'Model');
/**
 * Torniquete Model
 *
 */
class Torniquete extends AppModel {

}
